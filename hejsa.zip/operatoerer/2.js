var tal1 = 20;
var tal2 = 50;

// tal1 += tal2;
// console.log(tal1);
// tal1 -= tal2;
// console.log(tal1);
// tal1 *= tal2;
// console.log(tal1);
// tal1/= tal2;
// console.log(tal1);
// tal2 %= tal1;
// console.log(tal2);