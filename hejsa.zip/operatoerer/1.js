var tal1 = 4;
var tal2 = 5;
console.log(tal1 + tal2);
console.log(tal1 - tal2);
console.log(tal1 * tal2);
console.log(tal1 / tal2);
console.log(tal2 % tal1);
console.log(++tal1);
console.log(--tal2);
