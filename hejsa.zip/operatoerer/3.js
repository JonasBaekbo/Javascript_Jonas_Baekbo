var tal1 = 5;
var tal2 = 15;

if(tal1 < 10 && tal2 > 10){
    console.log('Betingelserne er opfyldt!');
}