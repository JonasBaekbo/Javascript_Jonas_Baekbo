var tal1 = 5;
var tal2 = 10;
if(tal1 == 5 || tal == 10){
    console.log("Yeees!");
}