var index = 0;
do{
console.log("Den bliver ved!");
index++;
}while(index < 10);