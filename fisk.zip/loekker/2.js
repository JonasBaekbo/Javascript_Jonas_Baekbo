var tal = 0;
while(tal < 25){
    console.log(++tal);
 }
 tal = 0;
 do{
    console.log(++tal);
 }while(tal < 25);
for(tal = 1; tal < 26; tal++){
    console.log(tal);
}