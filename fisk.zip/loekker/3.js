for(var aar = 2017; aar > 1916; aar--){
    console.log(aar);
}