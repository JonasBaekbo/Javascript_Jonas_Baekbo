var musik = ["Sam Tsui", "Counting Crows", "Swedish House Mafia", "Dimitri Vegas & Like Mike"];
musik.forEach(function(navn, index, liste){
console.log(navn + ' har placering ' + index + ' på listen')
});