var navne = ["Jonas", "Natasja", "Marie", "Emil", "Sebastian", "Jørgen", "Claus", "Annette"];
navne.forEach(function(navn){
    console.log(navn);
});